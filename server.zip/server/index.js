require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const http = require("http");
const path = require("path");
const multer = require("multer");
const { Server } = require("socket.io");

const authRoutes = require("./routes/auth");
const friendRoutes = require("./routes/friend");
const messageRoutes = require("./routes/message");
const userRoutes = require("./routes/user");
const uploadRoutes = require("./routes/upload");

const Message = require("./models/Message");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" },
});

app.use(cors());
app.use(express.json());

// ✅ MongoDB connect
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

// ✅ API routes
app.use("/api/auth", authRoutes);
app.use("/api/friend", friendRoutes);
app.use("/api/message", messageRoutes);
app.use("/api/user", userRoutes);
app.use("/api/upload", uploadRoutes);

// ✅ Static serve for uploaded files
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.get("/", (req, res) => {
  res.send("API Running ✅");
});

// ✅ Multer config for local uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + "-" + file.originalname;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

// ✅ ONLINE USERS TRACKING
let onlineUsers = [];

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  // ✅ Add user
  socket.on("addUser", (userId) => {
    if (!onlineUsers.some((u) => u.userId === userId)) {
      onlineUsers.push({ userId, socketId: socket.id });
      console.log("Online users:", onlineUsers);
    }
    io.emit("updateOnlineUsers", onlineUsers.map((u) => u.userId));
  });

  // ✅ Send message (text OR file)
  socket.on("sendMessage", async (data) => {
    const { from, to, text, fileUrl, tempId } = data;

    if (!from || !to || (!text && !fileUrl)) {
      console.log("Invalid message data:", data);
      return;
    }

    try {
      const message = new Message({
        from,
        to,
        text: text || "",
        fileUrl: fileUrl || "",
        status: "sent",
      });

      await message.save();

      const payload = {
        ...data,
        _id: message._id,
        status: "sent",
      };

      const receiver = onlineUsers.find((u) => u.userId === to);
      if (receiver) {
        io.to(receiver.socketId).emit("receiveMessage", payload);
      }

      // ✅ Notify sender with real ID & status
      socket.emit("messageStatus", {
        messageId: message._id,
        tempId: tempId,
        status: "sent",
      });

    } catch (err) {
      console.log("Message save error:", err.message);
    }
  });

  // ✅ Delivered
  socket.on("delivered", async ({ messageId }) => {
    await Message.findByIdAndUpdate(messageId, { status: "delivered" });
    io.emit("messageStatus", { messageId, status: "delivered" });
  });

  // ✅ Read
  socket.on("read", async ({ messageId }) => {
    await Message.findByIdAndUpdate(messageId, { status: "read" });
    io.emit("messageStatus", { messageId, status: "read" });
  });

  // ✅ Disconnect
  socket.on("disconnect", () => {
    onlineUsers = onlineUsers.filter((u) => u.socketId !== socket.id);
    io.emit("updateOnlineUsers", onlineUsers.map((u) => u.userId));
    console.log("User disconnected:", socket.id);
  });
});
const downloadRoutes = require("./routes/download");
app.use("/api/download", downloadRoutes);






// ✅ Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () =>
  console.log(`Server running on http://localhost:${PORT}`)
);

const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({
  mode: { type: String, required: true },           // 'personal' or 'sharing'
  tripType: { type: String },                       // 'oneway' or 'round' (only for personal)
  pickup: { type: String, required: true },
  drop: { type: String, required: true },
  fromDate: { type: String, required: true },
  toDate: { type: String },                         // only for personal round
  seats: { type: Number },                          // only for sharing
  createdAt: { type: Date, default: Date.now },
   phone: {type: String},
   driverPhone: {type: String},
   status: {
  type: String,
  enum: ["waiting", "confirmed", "picked", "dropped", "cancelled"],
  default: "waiting",
},

});

module.exports = mongoose.model("Booking", bookingSchema);

// ✅ FILE: models/Message.js

const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema(
  {
    from: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    to: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    text: { type: String }, // text optional hai kyunki kabhi file hi hogi
    fileUrl: { type: String }, // ✅ Yeh zaruri hai file ke liye
    status: { type: String, enum: ["pending", "sent", "delivered", "read"], default: "sent" },
    deletedFor: [String],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Message", MessageSchema);

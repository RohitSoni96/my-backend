// const mongoose = require("mongoose");

// const rideSchema = new mongoose.Schema({
//   tripType: { type: String, enum: ["personal", "sharing"], required: true },
//   personalOption: { type: String, enum: ["oneway", "round"], default: null },
//   pickup: { type: String, required: true },
//   drop: { type: String, required: true },
//   seats: { type: Number, default: 1 },
//   fromDate: { type: Date, required: true },
//   toDate: { type: Date, required: true },
//   createdAt: { type: Date, default: Date.now }
// });

// module.exports = mongoose.model("Ride", rideSchema);
// models/Ride.js
const mongoose = require("mongoose");

const rideSchema = new mongoose.Schema({
  driverPhone: { type: String, required: true },
  pickup: { type: String, required: true },
  drop: { type: String, required: true },
  date: { type: String, required: true },
  seatsAvailable: { type: Number, required: true },
});

module.exports = mongoose.model("Ride", rideSchema);

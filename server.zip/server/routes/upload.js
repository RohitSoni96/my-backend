// ✅ routes/upload.js
const express = require("express");
const multer = require("multer");
const router = express.Router();
const path = require("path");

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

router.post("/", upload.single("file"), (req, res) => {
  const filePath = req.file.filename;
  const fileUrl = `${process.env.BASE_URL}/uploads/${filePath}`; // ✅ FULL URL

  res.json({ file: fileUrl });
});

module.exports = router;

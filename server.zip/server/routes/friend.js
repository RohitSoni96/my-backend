// ✅ routes/friend.js
const express = require("express");
const router = express.Router();
const User = require("../models/User");
const auth = require("../middleware/auth");

// ✅ Mutual friend add
router.post("/add", auth, async (req, res) => {
  const { friendEmail } = req.body;

  try {
    const user = await User.findById(req.user);
    const friend = await User.findOne({ email: friendEmail });

    if (!friend) return res.status(404).json({ msg: "Friend not found" });
    if (user._id.equals(friend._id)) return res.status(400).json({ msg: "Cannot add yourself!" });

    // Check if already friends
    if (user.friends.includes(friend._id))
      return res.status(400).json({ msg: "Already added" });

    // ✅ Push BOTH SIDES
    user.friends.push(friend._id);
    friend.friends.push(user._id);

    await user.save();
    await friend.save();

    res.json({ msg: "Friend added MUTUALLY ✅", friend });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

// ✅ Get my friends
router.get("/", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user).populate("friends");
    res.json(user.friends);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;

// routes/download.js
const express = require("express");
const path = require("path");
const router = express.Router();

// ✅ /api/download/:filename
router.get("/:filename", (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, "..", "uploads", filename);

  // ✅ Download response
  res.download(filePath, filename, (err) => {
    if (err) {
      console.log(err);
      res.status(404).json({ error: "File not found!" });
    }
  });
});

module.exports = router;

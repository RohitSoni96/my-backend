// ✅ routes/message.js
const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Message = require("../models/Message");

// ✅ Get messages between two users
router.get("/:from/:to", auth, async (req, res) => {
  const { from, to } = req.params;

  const messages = await Message.find({
    $or: [
      { from, to },
      { from: to, to: from },
    ],
  }).sort({ createdAt: 1 });

  res.json(messages);
});

// Delete for ME
router.post('/deleteForMe', async (req, res) => {
  const { ids, userId } = req.body; // frontend se selected ids aur current user id

  try {
    await Message.updateMany(
      { _id: { $in: ids } },
      { $addToSet: { deletedFor: userId } } // duplicate na ho isliye addToSet
    );
    res.json({ success: true });
  } catch (err) {
    console.error('Delete For Me Error:', err);
    res.status(500).json({ error: 'Delete For Me failed' });
  }
});
// Delete for EVERYONE
router.post("/deleteForEveryone", auth, async (req, res) => {
  const { ids } = req.body;

  await Message.deleteMany({ _id: { $in: ids } });

  res.json({ success: true });
});
router.post("/forward", async (req, res) => {
  try {
    const { messageIds, to, from } = req.body;

    for (const msgId of messageIds) {
      const original = await Message.findById(msgId);
      if (!original) continue;

      const newMsg = new Message({
        text: original.text,
        fileUrl: original.fileUrl,
        from,
        to,
        status: "sent",
      });

      await newMsg.save();

     
    }

    res.status(200).json({ success: true, message: "Messages forwarded!" });
  } catch (err) {
    console.error("Forward error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


module.exports = router;
